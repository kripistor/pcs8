import 'package:flutter/material.dart';
import 'package:pcs8/pages/product_list.dart';

import '../models/product_model.dart';
import 'add_product.dart';


class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text('Market Place', style: TextStyle(color: Colors.black)),
        ),
      ),
      body: ProductList(
        products: products,
        onDelete: (product) {
          setState(() {
            products.remove(product);
          });
        },
        onToggleFavorite: (product) {
          setState(() {
            product.isFavorite = !product.isFavorite;
          });
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AddProductPage(),
            ),
          ).then((newProduct) {
            if (newProduct != null) {
              setState(() {
                products.add(newProduct);
              });
            }
          });
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}