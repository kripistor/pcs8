import 'product_model.dart';

final List<Product> cart = [];